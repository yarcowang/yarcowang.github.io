import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type ReservationDocument = HydratedDocument<Reservation>;

@Schema()
export class Reservation {
  @Prop()
  guestName: string;

  @Prop()
  guestContactInfo: string;

  @Prop()
  expectedArrivalTime: string;

  @Prop()
  reservedTableSizeInfo: number;

  @Prop()
  status: number;
}

export const ReservationSchema = SchemaFactory.createForClass(Reservation);
