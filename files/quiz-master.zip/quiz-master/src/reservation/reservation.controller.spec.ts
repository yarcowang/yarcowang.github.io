import { Test, TestingModule } from '@nestjs/testing';
import { ReservationController } from './reservation.controller';
import { ReservationService } from './reservation.service';

const mockCreateReservationDto = {
  guestName: 'Guest 001',
  guestContactInfo: 'information...',
  expectedArrivalTime: '2023-05-01',
  reservedTableSizeInfo: 1,
  status: 0,
};
const mockReservation = {
  guestName: 'Guest 001',
  guestContactInfo: 'information...',
  expectedArrivalTime: '2023-05-01',
  reservedTableSizeInfo: 1,
  status: 0,
  _id: 'guest001',
};


describe('ReservationController', () => {
  let controller: ReservationController;
  let service: ReservationService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ReservationController],
      providers: [
        {
          provide: ReservationService,
          useValue: {
            create: jest.fn().mockResolvedValue(mockCreateReservationDto),
          }
        },
      ]
    }).compile();

    controller = module.get<ReservationController>(ReservationController);
    service = module.get<ReservationService>(ReservationService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should make reservation', async () => {
    const createSpy = jest
      .spyOn(service, 'create')
      .mockResolvedValueOnce(mockReservation);

    await controller.makeReservation(mockCreateReservationDto);
    expect(createSpy).toHaveBeenCalledWith(mockCreateReservationDto);
  });
});
