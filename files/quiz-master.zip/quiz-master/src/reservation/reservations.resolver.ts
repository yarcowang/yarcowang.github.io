import { ReservationService } from './reservation.service';
import { Resolver, Query, Args } from '@nestjs/graphql';

@Resolver('Reservation')
export class ReservationsResolver {
  constructor(private readonly reservationService: ReservationService) {}

  @Query('reservations')
  async getReservations(
    @Args('date') date: string,
    @Args('status') status: number,
    @Args('first') first: number,
    @Args('offset') offset: number,
  ) {
    return this.reservationService.findAllByDateAndStatus(
      date,
      status,
      first,
      offset,
      false,
    );
  }

  @Query('reservation')
  async getReservationById(@Args('id') id: string) {
    return this.reservationService.findById(id);
  }

}
