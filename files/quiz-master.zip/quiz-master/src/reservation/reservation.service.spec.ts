import { Test, TestingModule } from '@nestjs/testing';
import { ReservationService } from './reservation.service';
import { ReservationModule } from './reservation.module';
import { Model, Promise } from 'mongoose';
import { getModelToken, MongooseModule } from '@nestjs/mongoose';
import { Reservation, ReservationSchema } from './schemas/reservation.schema';
import { stringify } from 'ts-jest';

const mockReservation = {
  guestName: 'Guest 001',
  guestContactInfo: 'information...',
  expectedArrivalTime: '2023-05-01',
  reservedTableSizeInfo: 1,
  status: 0,
};
const mockReservation2 = {
  guestName: 'Guest 002',
  guestContactInfo: 'information...',
  expectedArrivalTime: '2023-05-01',
  reservedTableSizeInfo: 1,
  status: 0,
};
const mockReservations = [
  mockReservation
];

describe('ReservationService', () => {
  let service: ReservationService;
  let model: Model<Reservation>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [
        MongooseModule.forRoot('mongodb://localhost/quiz'), // useValue doesn't work, so we still need connection
        ReservationModule,
      ],
      providers: [
        ReservationService,
        {
          provide: getModelToken(Reservation.name),
          useValue: {
            new: jest.fn().mockResolvedValue(mockReservation),
            constructor: jest.fn().mockResolvedValue(mockReservation),
            find: jest.fn(),
            findAllByDateAndStatus: jest.fn(),
            findByName: jest.fn().mockImplementation(() => Promise.Resolve(mockReservation)),
            findByIdAndUpdate: jest.fn().mockImplementation(() => Promise.Resolve(mockReservation2)),
            create: jest.fn().mockImplementation(() => Promise.Resolve(mockReservation)),
            exec: jest.fn(),
            save: jest.fn().mockResolvedValue(mockReservation2),
          },
        },
      ],
    }).compile();

    service = module.get<ReservationService>(ReservationService);
    model = module.get<Model<Reservation>>(getModelToken(Reservation.name));
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should make reservation', async () => {
    const newReservation = await service.create({
      guestName: 'Guest 001',
      guestContactInfo: 'information...',
      expectedArrivalTime: '2023-05-01',
      reservedTableSizeInfo: 1,
      status: 1,
    });

    expect(newReservation.guestName).toBe('Guest 001');
  });

  it('should return the reservation', async () => {
    const reservation = await service.findByName('Guest 001');

    expect(reservation.guestName).toBe('Guest 001');
  });

  it('should return several reservations', async () => {
    jest.spyOn(model, 'find').mockReturnValue({
      skip: jest.fn().mockReturnThis(),
      limit: jest.fn().mockReturnThis(),
      exec: jest.fn().mockResolvedValue(mockReservations),
    } as any);
    const reservations = await service.findAllByDateAndStatus();

    expect(reservations[0]).toEqual(mockReservations[0]);
  });

  it('should change the name of the reservation', async () => {
    const reservation = await service.findByName('Guest 001');
    reservation.guestName = 'Guest 002';
    const newReservation = await service.updateById(reservation['_id'], {
      ...JSON.parse(stringify(reservation)),
    });
    expect(newReservation.guestName).toBe('Guest 002');
  });

  it('should change the status of the reservation', async () => {
    const reservation = await service.findByName('Guest 001');
    const newReservation = await service.changeStatusById(reservation['_id'], 1);
    expect(newReservation.status).toBe(1);
  });

});
