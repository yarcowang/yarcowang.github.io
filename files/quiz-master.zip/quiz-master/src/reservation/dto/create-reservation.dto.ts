export class CreateReservationDto {
  readonly guestName: string;
  readonly guestContactInfo: string;
  readonly expectedArrivalTime: string;
  readonly reservedTableSizeInfo: number;
  readonly status: number;
}
