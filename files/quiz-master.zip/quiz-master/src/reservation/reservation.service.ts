import { Model, ObjectId } from 'mongoose';
import { Injectable } from '@nestjs/common';
import { Reservation } from './schemas/reservation.schema';
import { InjectModel } from '@nestjs/mongoose';
import { CreateReservationDto } from './dto/create-reservation.dto';
import { UpdateReservationDto } from './dto/update-reservation.dto';

@Injectable()
export class ReservationService {
  constructor(
    @InjectModel(Reservation.name) private reservationModel: Model<Reservation>,
  ) {}

  async create(
    createReservationDto: CreateReservationDto,
  ): Promise<Reservation> {
    const createdReservation = new this.reservationModel(createReservationDto);
    return createdReservation.save();
  }

  async findByName(name: string): Promise<Reservation> {
    return this.reservationModel.findOne({ guestName: name });
  }

  async findById(id: string): Promise<Reservation> {
    return this.reservationModel.findById(id);
  }

  async findAllByDateAndStatus(
    reservationDate?: string,
    status?: number,
    pageno?: number,
    pagesize?: number,
    is_paginate = true
  ) {
    let filters = {};
    if (reservationDate) {
      filters['expectedArrivalTime'] = reservationDate;
    }
    if (status) {
      filters['status'] = status;
    }
    // TODO: pagination can be a simple component
    pageno || (pageno = 1);
    pagesize || (pagesize = 20);

    let first, offset
    if (is_paginate) {
      first = (pageno - 1) * pagesize;
      offset = pagesize;
    } else {
      first = pageno;
      offset = pagesize;
    }

    return this.reservationModel.find(filters).skip(first).limit(offset).exec();
  }

  async updateById(id: string, updateReservationDto: UpdateReservationDto) {
    return this.reservationModel.findByIdAndUpdate(id, updateReservationDto, {new: true});
  }

  async changeStatusById(id: string, status: number) {
    return this.reservationModel.findByIdAndUpdate(id, {status}, {new: true});
  }
}
