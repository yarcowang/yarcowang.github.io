import { Body, Controller, Post, Patch, Param, Get, Query } from "@nestjs/common";
import { CreateReservationDto } from './dto/create-reservation.dto';
import { ReservationService } from './reservation.service';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Reservation } from './schemas/reservation.schema';
import { UpdateReservationDto } from './dto/update-reservation.dto';

@Controller('reservation')
export class ReservationController {
  constructor(private readonly reservationService: ReservationService) {
  }

  @Post()
  @ApiOperation({ summary: 'make a reservation' })
  @ApiResponse({
    status: 200,
    description: 'reservation data just created',
    type: Reservation,
  })
  async makeReservation(@Body() createReservationDto: CreateReservationDto) {
    const reservation = await this.reservationService.create(
      createReservationDto,
    );
    return reservation;
  }

  @Get(':id')
  async getReservationById(@Param('id') id: string) {
    const reservation = await this.reservationService.findById(id);
    return reservation;
  }

  @Get()
  async getReservations(@Query('date') date: string, @Query('status') status: number, @Query('pageno') pageno: number, @Query('pagesize') pagesize: number) {
    const reservations = await this.reservationService.findAllByDateAndStatus(
      date,
      status,
      pageno,
      pagesize,
    );
    return reservations;
  }

  @Patch(':id')
  async updateReservation(@Param('id') id: string, @Body() updateReservationDto: UpdateReservationDto) {
    const reservation = await this.reservationService.updateById(
      id,
      updateReservationDto,
    );
    return reservation;
  }

  @Patch(':id/:op')
  async cancelReservation(@Param('id') id: string, @Param('op') op: string) {
    // TODO: we can use workflow/statemachine to handle complex situaction,
    // i.e., when some states can go to multiple states, and some states can only go to one state
    // but here, we just use if-else to handle it

    // op can be: cancel & complete
    // 1 = init, 2 = cancel, 3 = complete
    const ops = { cancel: 2, complete: 3 };
    const reservation = await this.reservationService.changeStatusById(
      id,
      ops[op],
    );
    return reservation;
  }



}
